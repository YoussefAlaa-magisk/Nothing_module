# Nothing_module

- (Nothing module working on any device)
- (rooted && unlcoked bootloader)
- (for laugh not a real module its only for laugh )
